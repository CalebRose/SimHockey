package engine

import "fmt"

func Logger(message string) {
	fmt.Println(message)
}
